var prefix = window.location.pathname.substr(0, window.location.pathname.toLowerCase().lastIndexOf("/extensions") + 1);
var config = {
  host: window.location.hostname,
  prefix: prefix,
  port: window.location.port,
  isSecure: window.location.protocol === "https:"
};
var appId = "Portal_DEV.qvf";
// let appId = "fcae1630-9310-4cba-8877-52312b4dad61";
var baseUrl = (config.isSecure ? "https://" : "http://") + config.host + (config.port ? ":" + config.port : "") + config.prefix + "resources";

window.require.config({
  baseUrl: baseUrl
});

require(["js/qlik"], function (qlik) {

  angular.module('app')
    .constant('qlik', {
      instance: qlik,
      config: qlik,
      appId: appId
    });

  angular.bootstrap(document, ['app', 'qlik-angular']);
});